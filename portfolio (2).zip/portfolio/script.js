function openpop1() {
    document.getElementById("popup1").style.display = "block";
}
function closepop1() {
    document.getElementById("popup1").style.display = "none";
}
function openpop2() {
    document.getElementById("popup2").style.display = "block";
}
function closepop2() {
    document.getElementById("popup2").style.display = "none";
}
function openpop3() {
    document.getElementById("popup3").style.display = "block";
}
function closepop3() {
    document.getElementById("popup3").style.display = "none";
}
function openpop4() {
    document.getElementById("popup4").style.display = "block";
}
function closepop4() {
    document.getElementById("popup4").style.display = "none";
}
function openpop5() {
    document.getElementById("popup5").style.display = "block";
}
function closepop5() {
    document.getElementById("popup5").style.display = "none";
}
function openpop6() {
    document.getElementById("popup6").style.display = "block";
}
function closepop6() {
    document.getElementById("popup6").style.display = "none";
}
function openpop7() {
    document.getElementById("popup7").style.display = "block";
}
function closepop7() {
    document.getElementById("popup7").style.display = "none";
}